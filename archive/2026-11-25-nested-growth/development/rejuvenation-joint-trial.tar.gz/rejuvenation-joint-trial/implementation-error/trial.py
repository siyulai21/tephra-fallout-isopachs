"""Unpublished fixed-target MCMC experiment; preserves every inspected checkpoint."""
import argparse
from pathlib import Path
import numpy as np
from scipy.special import gammaln
from src.empirical_isopach.core.audit import audited_data
from src.empirical_isopach.core.catalog import datasets
from src.empirical_isopach.models.directional.ensemble.members import splits
from src.empirical_isopach.models.nested.geometry import ANGLES, positions
from src.empirical_isopach.models.nested.profile import budget_parameters, log_profile, integrated
from src.empirical_isopach.models.nested.continuation import outer_status
from src.empirical_isopach.models.nested.footprints import growth, numerics, diagnostics
from src.empirical_isopach.models.nested.footprints.flow import TrainingRanks
from src.empirical_isopach.models.nested.footprints.continuous import FlowField, continued
from src.empirical_isopach.models.nested.study import digest, write_json


def run(slug, key, n=3072, moves=2048):
    rec=next(x for x in datasets() if x['slug']==slug)
    data,meta=audited_data(rec['path']);train=data
    if key!='full':
        _,train,_=next(x for x in splits(data,meta['vent_lonlat'][1],'geographic') if x[0]==int(key[-1]))
    source=Path('results/nested-adaptive/continuous')/slug/'refinement-24576'/(key+'.npz')
    model=FlowField.load(source)
    dest=Path('results/nested-adaptive/rejuvenation-joint-trial')/slug/key;dest.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(149724)
    idx=np.concatenate([rng.choice(p,n,replace=False) for p in np.array_split(np.arange(len(model.z)),4)])
    z=np.column_stack((model.z[idx],model.warp[idx]));g=model.geometry[idx].copy();tail=model.power_tail[idx].copy()
    count=len(z);radius=TrainingRanks(*positions(train.xy,model.latitude));prior=growth.prior()
    # A fixed full-pilot proposal. It changes no target probability; each
    # population has separate states and random moves, with no cross-resampling.
    pilot=np.column_stack((model.z,model.warp));codes=2*model.geometry+model.power_tail
    labels,counts=np.unique(codes,return_counts=True);weights=counts/counts.sum()
    means=[];chols=[];inverses=[];logdet=[]
    family=np.array([s.family for s in growth.SHAPES])
    group_cov={f:np.cov(pilot[family[model.geometry//ANGLES]==f].T)+.03*np.eye(8) for f in np.unique(family[model.geometry//ANGLES])}
    for code,size in zip(labels,counts):
        sample=pilot[codes==code];mean=sample.mean(axis=0);means.append(mean)
        common=group_cov[family[(code//2)//ANGLES]]
        cov=np.cov(sample.T) if size>8 else common
        alpha=size/(size+32.)
        chol=np.linalg.cholesky((alpha*cov+(1-alpha)*common+.01*np.eye(8))*.6)
        chols.append(chol);inverses.append(np.linalg.inv(chol));logdet.append(np.log(np.diag(chol)).sum())
    means,chols,inverses,logdet=map(np.asarray,(means,chols,inverses,logdet))
    lookup=np.full(2*len(prior),-1,int);lookup[labels]=np.arange(len(labels))
    constant=gammaln(6.5)-gammaln(2.5)-4*np.log(5*np.pi)
    def proposal_log(coords,geom,outer):
        group=lookup[2*geom+outer];valid=group>=0;out=np.full(len(coords),-np.inf)
        j=group[valid];delta=np.einsum('nij,nj->ni',inverses[j],coords[valid]-means[j])
        out[valid]=np.log(weights[j])+constant-logdet[j]-6.5*np.log1p(np.sum(delta**2,axis=1)/5)
        return out
    neighbours=[]
    for a in growth.SHAPES:
        va=vars(a)
        neighbours.append(np.array([j for j,b in enumerate(growth.SHAPES) if a.family==b.family
          and set(va)==set(vars(b)) and sum(va[k]!=vars(b)[k] for k in va)<=1]))
    degree=np.array([len(x) for x in neighbours]);table=np.zeros((len(neighbours),degree.max()),int)
    for i,v in enumerate(neighbours):table[i,:len(v)]=v
    rank_scale=np.mean(np.log(np.maximum(radius.base[:,np.any(radius.base>0,axis=0)],1e-10)),axis=1)
    selected=np.unique(np.linspace(0,len(train.xy)-1,min(32,len(train.xy))).astype(int));small=radius.subset(selected)
    def likelihood(coords,geom,outer):
        return numerics.log_events(radius.at(coords,geom),np.array(budget_parameters(coords[:,:6],outer)),outer,
            train.log_value,train.log_sd,train.censored,train.lower_censored,train.interval_log_upper)
    def logprior(coords):
        return -.5*np.sum(coords**2,axis=1)+.5*coords[:,3]**2-2*np.log1p(coords[:,3]**2/3)
    ll=likelihood(z,g,tail);lp=logprior(z);step=np.array([.2,.2]);records=[];rates=np.zeros(5)
    def check(iteration):
        current=continued(z[:,:6],g,tail,model.latitude,z[:,6:],train,seed=97231)
        volume=np.array([np.quantile(integrated(z[p,:6],tail[p]),[.025,.5,.975]) for p in np.array_split(np.arange(count),4)])
        spread=np.ptp(np.log(volume),axis=0)
        med=np.array([np.median(current.subset(p).field(train.xy),axis=0) for p in np.array_split(np.arange(count),4)])
        diff=np.ptp(med,axis=0);spatial=dict(median=float(np.median(diff)),p95=float(np.quantile(diff,.95)))
        spatial['passed']=spatial['median']<.15 and spatial['p95']<.4
        intrinsic=bool(spread[1]<=np.log(1.35) and max(spread[[0,2]])<=np.log(2))
        outer=outer_status(current);field=diagnostics.population_field_check(current,train) if key=='full' else None
        r=dict(iteration=iteration,intrinsic_quantiles=volume.tolist(),intrinsic_passed=intrinsic,continuation=outer,
               sites=spatial,field=field,tail_fractions=[float(x.mean()) for x in np.array_split(tail,4)],
               mean_log_likelihood=[float(x.mean()) for x in np.array_split(ll,4)],acceptance=(rates/max(1,iteration)).tolist())
        r['passed']=intrinsic and outer['passed'] and spatial['passed'] and (field is None or field['passed'])
        packet=dest/f'moves-{iteration}.npz';np.savez_compressed(packet,**vars(current));r['posterior_sha256']=digest(packet)
        records.append(r);write_json(dest/'trial.json',dict(source_sha256=digest(source),script_sha256=digest(__file__),checks=records))
        print(slug,key,r,flush=True)
    check(0)
    for iteration in range(1,moves+1):
        # Adapt for a finite 256-move warmup, separately within each independent population.
        if iteration==1 or (iteration<=256 and iteration%32==1):
            chols=[np.linalg.cholesky(np.cov(part.T)+.015*np.eye(8)) for part in np.array_split(z,4)]
            warps=[np.linalg.cholesky(np.cov(part[:,6:].T)+.015*np.eye(2)) for part in np.array_split(z,4)]
        proposed=z.copy();warp=iteration%4==0
        for p,(chol,wc) in enumerate(zip(chols,warps)):
            sl=slice(p*n,(p+1)*n)
            if warp:proposed[sl,6:]+=step[1]*rng.normal(size=(n,2))@wc.T
            else:proposed[sl,:6]+=step[0]*rng.normal(size=(n,6))@chol[:6,:6].T
        new=likelihood(proposed,g,tail);newprior=logprior(proposed)
        take=np.log(rng.random(count))<new-ll+newprior-lp
        z[take]=proposed[take];ll[take]=new[take];lp[take]=newprior[take];rates[int(warp)]+=take.mean()
        near=(g//ANGLES)*ANGLES+(g%ANGLES+rng.integers(-4,5,count))%ANGLES
        global_draw=rng.choice(len(prior),count,p=prior);mode=rng.random(count)
        same=(global_draw//ANGLES)*ANGLES+g%ANGLES
        ids=g//ANGLES;local=table[ids,(rng.random(count)*degree[ids]).astype(int)]*ANGLES+g%ANGLES
        geom=np.where(mode<.25,near,np.where(mode<.75,local,np.where(mode<.95,same,global_draw)))
        hastings=np.where((mode>=.25)&(mode<.75),np.log(degree[g//ANGLES]/degree[geom//ANGLES])+np.log(prior[geom]/prior[g]),0.)
        moved=z.copy();moved[:,1]+=(rank_scale[geom]-rank_scale[g])/1.6
        moved[:,0]+=np.median(log_profile(small.at(z,g),z[:,:6],tail)-log_profile(small.at(moved,geom),moved[:,:6],tail),axis=1)/2.8
        new=likelihood(moved,geom,tail);newprior=logprior(moved)
        take=np.log(rng.random(count))<new-ll+newprior-lp+hastings
        z[take]=moved[take];g[take]=geom[take];ll[take]=new[take];lp[take]=newprior[take];rates[2]+=take.mean()
        if iteration%4==0:
            moved=z.copy()
            moved[:,0]+=np.median(log_profile(small.at(z,g),z[:,:6],tail)-log_profile(small.at(z,g),z[:,:6],~tail),axis=1)/2.8
            new=likelihood(moved,g,~tail);newprior=logprior(moved)
            take=np.log(rng.random(count))<new-ll+newprior-lp
            z[take]=moved[take];tail[take]=~tail[take];ll[take]=new[take];lp[take]=newprior[take];rates[3]+=take.mean()
            group=rng.choice(len(labels),count,p=weights)
            normal=rng.normal(size=(count,8))/np.sqrt(rng.chisquare(5,count)[:,None]/5)
            proposed=means[group]+np.einsum('nij,nj->ni',chols[group],normal)
            geom=labels[group]//2;outer=(labels[group]%2).astype(bool)
            new=likelihood(proposed,geom,outer);newprior=logprior(proposed)
            ratio=new-ll+newprior-lp+np.log(prior[geom]/prior[g])+proposal_log(z,g,tail)-proposal_log(proposed,geom,outer)
            take=np.log(rng.random(count))<ratio
            z[take]=proposed[take];g[take]=geom[take];tail[take]=outer[take];ll[take]=new[take];lp[take]=newprior[take];rates[4]+=take.mean()
        if iteration in (256,512,1024,2048):check(iteration)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('case');p.add_argument('part');p.add_argument('--n',type=int,default=3072);p.add_argument('--moves',type=int,default=2048)
    a=p.parse_args();run(a.case,a.part,a.n,a.moves)
