import importlib.util,sys,json
from pathlib import Path
import numpy as np
from src.empirical_isopach.core.audit import audited_data
from src.empirical_isopach.core.catalog import datasets
from src.empirical_isopach.models.nested.footprints import growth
from src.empirical_isopach.models.nested.footprints.continuous import fit_field,engine,predictions
from src.empirical_isopach.models.nested.report import MapView
from src.empirical_isopach.models.nested.study import digest
from src.empirical_isopach.visualization.deposit_field import sample_field
spec=importlib.util.spec_from_file_location('src.empirical_isopach.models.nested.footprints.advecting_growth','results/nested-adaptive/advecting_growth.py')
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
growth.fronts=module.fronts
growth.SHAPES=module.SHAPES
growth.prior=module.prior
from src.empirical_isopach.models.nested.footprints import flow_inference
flow_inference.SHAPES=module.SHAPES
flow_inference.geometry_probabilities=module.prior
growth.lookup.cache_clear()
root=Path('results/nested-adaptive/advecting-trial');root.mkdir(exist_ok=True)
for slug in ('ilopango-tbj','mazama','b-tm'):
 rec=next(r for r in datasets() if r['slug']==slug)
 data,meta=audited_data(rec['path'])
 model,check=fit_field(data,meta['vent_lonlat'][1],initial=1536,ceiling=1536)
 out=root/slug;out.mkdir(exist_ok=True)
 np.savez_compressed(out/'full.npz',**vars(model))
 field=sample_field(MapView(model.reduced(1536)),data,model.latitude,257,384)
 np.savez_compressed(out/'median-grid.npz',radii_km=field.radii,log10_cm=field.log10_cm,axis=field.axis)
 median=np.median(model.field(data.xy),axis=0);err=median-data.log_value
 result=dict(case=slug,base_engine_sha256=engine(),growth_override_sha256=digest('results/nested-adaptive/advecting_growth.py'),input_sha256=meta['input_sha256'],numerics=check,
             measured_log_rmse=float(np.sqrt(np.mean(err[~data.censored]**2))),measured_median_abs_log_error=float(np.median(abs(err[~data.censored]))),
             predictions=predictions(model,data),volume_quantiles_km3=np.quantile(model.volume(),[.025,.5,.975]).tolist())
 (out/'full.json').write_text(json.dumps(result,indent=2))
 print(slug,check['passed'],result['measured_log_rmse'],result['measured_median_abs_log_error'],flush=True)
