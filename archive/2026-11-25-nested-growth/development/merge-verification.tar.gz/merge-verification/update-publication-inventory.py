from pathlib import Path
from hashlib import sha256
import json
import subprocess

previous_inventory_revision='0d0e5a1cac6f0a2eb22dd667b55558836aab1d98'
preceding_main='beee82b7020d62aa2c3dc847d74e45dcf651084f'
merged_upstream='4a693358a79c7cfc0ab5b562fb34533e7c1f56bc'
inventory=Path('benchmarks/published-evidence.sha256')
audit=Path('archive/2026-11-25-nested-growth/publication-inventory-changes.json')
original=dict(line.split('  ',1)[::-1] for line in subprocess.check_output(
    ['git','show',f'{previous_inventory_revision}:{inventory}']).decode().splitlines())
changed=subprocess.check_output(['git','diff','--name-only',preceding_main]).decode().splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard']).decode().splitlines()
names=set(original)
prefixes=('src/','benchmarks/','docs/','comparisons/','eruptions/','archive/','data/')
names.update(n for n in changed+untracked if n.startswith(prefixes) and Path(n).is_file()
             and Path(n) not in (inventory,audit))
values={n:sha256(Path(n).read_bytes()).hexdigest() for n in sorted(names)}
changes={}
for n,after in values.items():
    before=original.get(n)
    if before==after:continue
    prior=subprocess.run(['git','show',f'{preceding_main}:{n}'],capture_output=True)
    upstream=subprocess.run(['git','show',f'{merged_upstream}:{n}'],capture_output=True)
    changes[n]=dict(inventory_before=before,
        preceding_main_sha256=sha256(prior.stdout).hexdigest() if prior.returncode==0 else None,
        merged_upstream_sha256=sha256(upstream.stdout).hexdigest() if upstream.returncode==0 else None,
        current_sha256=after)
sources=subprocess.check_output(['git','diff','--name-only',preceding_main,'--','data/eruptions','data/audits']).decode()
assert not sources,sources
audit.write_text(json.dumps(dict(preceding_main=preceding_main,merged_upstream=merged_upstream,previous_inventory_revision=previous_inventory_revision,
    note='Intentional current reports, code, presentation and retained provenance updates. Original accepted CSVs and source audit evidence are unchanged. Pre-existing inventory mismatches are distinguished by the preceding_main hash. The merged_upstream hash identifies the concurrent directional v6 publication incorporated before merging the nested method.',
    added_paths=sorted(set(values)-set(original)),changes=changes),indent=2)+'\n')
inventory.write_text(''.join(f'{h}  {n}\n' for n,h in values.items()))
print('Inventory:',len(values),'files;',len(changes),'new or changed entries; source CSVs and audit bytes unchanged')
