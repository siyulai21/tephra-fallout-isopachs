"""Broad departure from source-focused ellipses, with a nonzero independent component."""
import numpy as np
from src.empirical_isopach.models.nested.footprints import growth

def factors():
    weights=np.ones(len(growth.SHAPES));groups={}
    for i,s in enumerate(growth.SHAPES):
        if s.family not in ('round','detached'):
            key=tuple((k,v) for k,v in vars(s).items() if k!='focus')
            groups.setdefault(key,[]).append(i)
    for ids in groups.values():
        shapes=[growth.SHAPES[i] for i in ids]
        focus=np.array([s.focus for s in shapes])
        reference=np.sqrt(1.-shapes[0].aspect**-4)
        local=np.exp(-.5*((focus-reference)/.25)**2)
        weights[ids]=.2+.8*local/local.mean()
    return weights
