from pathlib import Path
import json
import numpy as np
from coupled_focus_prior import factors
from src.empirical_isopach.core.audit import audited_data
from src.empirical_isopach.core.catalog import datasets
from src.empirical_isopach.models.nested.footprints import growth
from src.empirical_isopach.models.nested.footprints.continuous import FlowField,predictions
from src.empirical_isopach.models.nested.footprints.flow_inference import systematic
from src.empirical_isopach.models.nested.report import MapView
from src.empirical_isopach.models.nested.study import digest
from src.empirical_isopach.visualization.deposit_field import sample_field
root=Path('results/nested-adaptive/focus-prior-trial')
for slug in ('ilopango-tbj','aso-4','mazama','minoan'):
 rec=next(r for r in datasets() if r['slug']==slug)
 data,meta=audited_data(rec['path'])
 parent=Path('results/nested-adaptive/continuous')/slug/'full.npz'
 model=FlowField.load(parent);weight=factors()[model.geometry//48]
 indices=[];ess=[]
 for k,ids in enumerate(np.array_split(np.arange(len(model.z)),4)):
  w=weight[ids]/weight[ids].sum();ess.append(float(1/(w@w)))
  rng=np.random.default_rng(57829+k)
  indices.extend(ids[rng.permutation(systematic(w,rng))].tolist())
 model=model.subset(np.array(indices))
 out=root/slug;out.mkdir(parents=True,exist_ok=True)
 (out/'footprints').mkdir(exist_ok=True)
 np.savez_compressed(out/'footprints/full-selected.npz',**vars(model))
 field=sample_field(MapView(model.reduced(1536)),data,model.latitude,257,384)
 np.savez_compressed(out/'median-grid.npz',radii_km=field.radii,log10_cm=field.log10_cm,axis=field.axis)
 receipt=dict(input_sha256=meta['input_sha256'],source_sha256=digest(parent),
              prior_source_sha256=digest('results/nested-adaptive/coupled_focus_prior.py'),population_effective_draws=ess)
 (out/'trial.json').write_text(json.dumps(receipt,indent=2))
 print(slug,ess,flush=True)
 from benchmarks.nested_growth_review import assess
 assess((rec,root,root/'review','release',Path('results/nested-adaptive/baseline'),1536))
