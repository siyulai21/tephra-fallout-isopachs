import importlib.util,sys,shutil
from pathlib import Path
from src.empirical_isopach.models.nested.footprints import growth
from src.empirical_isopach.core.catalog import datasets
from benchmarks.nested_growth_review import assess
spec=importlib.util.spec_from_file_location('src.empirical_isopach.models.nested.footprints.round_core_growth','results/nested-adaptive/round_core_growth.py')
module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
growth.fronts=module.fronts;growth.SHAPES=module.SHAPES;growth.prior=module.prior;growth.lookup.cache_clear()
root=Path('results/nested-adaptive/round-core-trial')
for rec in datasets():
 folder=root/rec['slug']
 if not (folder/'full.json').exists():continue
 (folder/'footprints').mkdir(exist_ok=True)
 shutil.copyfile(folder/'full.npz',folder/'footprints/full-selected.npz')
 assess((rec,root,root/'review','release',Path('results/nested-adaptive/baseline'),1536))
