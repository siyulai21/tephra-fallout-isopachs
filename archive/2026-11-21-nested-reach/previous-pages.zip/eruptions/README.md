# Eruption results

Choose an eruption for its accepted observations, five volume estimates, maps and local support audit. All volumes measure bulk airborne fallout. The two regional fits cover the observation hull. The three global fits extend across unsampled ground.

| Eruption | Principal directional volume (km³) | Principal spherical volume (km³) | Nested volume median (km³) | Accepted thickness evidence | What to keep in mind |
|---|---:|---:|---:|---|---|
| [Aso-4](aso-4/README.md) | **659.1** | **1,069.7** | **2,513.9** | 83 exact, 3 lower bounds, 1 upper bound | Reviewed cruise positions and bounds. Marine sampling leaves the source region and several bearings poorly constrained. |
| [B-Tm](b-tm/README.md) | **33.6** | **47.0** | **90.4** | 64 measurements, 3 reported lower bounds, 1 reported and 3 interpreted upper bounds | Combined fallout. Lake shard profiles and a peat mass budget constrain the contours. |
| [Ilopango TBJ, Unit G](ilopango-tbj/README.md) | **40.8** | **190.9** | **50.5** † | 52 measurements, 4 lower bounds | Unit G co-ignimbrite fallout. The spherical upper interval is provisional. Northeast measurements are proximal and southwest measurements are distal. |
| [Mazama](mazama/README.md) | **166.1** | **212.9** | **411.2** | 45 exact | The published calculation uses the supplied acceptance flags. |
| [Minoan](minoan/README.md) | **28.8** | **40.8** | **37.6** | 92 exact, 9 lower bounds | All accepted Plinian and co-ignimbrite fallout fans form one deposit. |
| [Sakurajima Satsuma](sakurajima-satsuma/README.md) | **7.1** | **11.3** | **12.5** † | 50 measurements, 5 lower bounds, 2 upper bounds | All eight bearings are sampled. Both northwest sites are proximal. The single distal western core materially constrains the spherical upper tail. |
| [Tambora](tambora/README.md) | **95.7** | **162.3** | **146.9** | 26 exact | Four of six full-data directional fits carry a numerical warning. |
| [Younger Toba Tuff (YTT)](ytt/README.md) | **900.6** | **1,510.5** | **1,543.0** † | 46 exact | The audited principal selection includes two qualified Maninjau beds and the U1445B core. |

The spherical volume column gives the median of integrated whole deposits under the common bearing-continuation policy. [Spherical estimates and validation](../comparisons/spherical-mixture/README.md)

The directional volume column integrates the quantitative uncertain-fan-direction median map across the Earth. Each case gives its conditional complete-deposit interval and the matched fixed-direction control. [Compare directional extent across eruptions](../comparisons/directional/README.md)

For the same geographic prediction test across eruptions, see the [cross-eruption comparison](../comparisons/README.md).

The nested volume is the median integral of complete deposits. A dagger marks a full fit with a numerical warning. [Conditional intervals, distal contributions and matched tests](../comparisons/nested-isopachs/README.md)
