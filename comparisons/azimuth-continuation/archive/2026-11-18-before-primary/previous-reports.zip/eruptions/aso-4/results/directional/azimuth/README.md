# Aso-4 · directional extent

The same 87 accepted observations give a **779.7 km³** median-map integral with fixed fan directions and **659.1 km³** when an unsampled fan can turn. These two fits use identical observations and structure weights. The primary six-structure estimate on the case home uses its original calibration.

Under uncertain azimuth, integrating each complete deposit gives a volume median of **916.3 km³** and a conditional 95% range of **297.9–3,511.5 km³**. Measured interpolation triangles contribute 3.8% of the median-map volume. The rest relies on continuation.

![Median isopachs and quantitatively bracketed segments](median-isopachs.png)

Solid marks require a triangle whose measured sites bracket the thickness and whose posterior crossing probability reaches 90%. Dashes show the remaining median contour. White circles are thickness observations. An empty sector can contain fallout.

## Reach from the volcano

Distances are great-circle kilometres to the first outward crossing on each compass ray. The area columns give the entire 10 cm footprint in the corresponding 45° sector, including detached areas. Together they distinguish a long point on a contour from an entire broad lobe.

| Bearing | Fixed 10 cm reach (km) | Uncertain 10 cm reach (km) | Fixed ≥10 cm area (km²) | Uncertain ≥10 cm area (km²) |
|---|---:|---:|---:|---:|
| N | 249.7 | 248.9 | 24,521 | 22,755 |
| NE | 301.6 | 300.9 | 35,173 | 35,173 |
| E | 292.3 | 292.5 | 32,061 | 31,591 |
| SE | 241.8 | 229.9 | 23,681 | 22,187 |
| S | 218.1 | 194.2 | 18,765 | 14,733 |
| SW | 231.8 | 199.1 | 20,339 | 15,454 |
| W | 218.8 | 189.1 | 19,026 | 14,152 |
| NW | 214.4 | 191.9 | 18,041 | 14,442 |

![Probability that a deposit reaches ten centimetres](exceedance.png)

The 50% and 90% probability lines answer different questions. At a location on the 90% line, nine in ten model draws reach 10 cm. These are pointwise probabilities conditional on the model. Joint confidence over an entire region requires a different calculation.

## Withheld observations

Each row averages negative log predictive scores over equally weighted folds. Lower scores predict the withheld thicknesses and limits better. The passing-only columns exclude numerical failures. A dash means no fold passed.

| Deletion | All estimable folds | Fixed | Uncertain | Passing folds | Fixed, passing | Uncertain, passing |
|---|---:|---:|---:|---:|---:|---:|
| geographic | 4 | 1.500 | 1.502 | 4 | 1.500 | 1.502 |
| quadrants | 3 | 1.302 | 1.566 | 3 | 1.302 | 1.566 |

[Predictions for every estimable held-out site](heldout.csv). The numerical record includes all planned folds, row identities, unscorable directions, fit warnings and phase-integration checks.

## Checks and reproducibility

The shared contour audit found eligible bands under none of the screened support policies. Audit status is completed. [All contour decisions and deletion failures](complete-contour-audit.json)

The spatial integration check passed at 8,192 points per scramble. The map used up to 64 posterior draws per chain and structure. Resolved contour areas passed the split-packet check. The joint-volume quantiles passed the split check.

All six full fits passed their sampling diagnostics.

[Numerical report, all sector volumes and sensitivities](report.json) · [Complete fields and per-field volumes](fields.npz) · [Plotted grids](map-grid.npz) · [Fragment decisions](fragment-decisions.csv) · [Bracketed coordinates](bracketed-fragments.csv) · [File hashes](artifacts.json)
