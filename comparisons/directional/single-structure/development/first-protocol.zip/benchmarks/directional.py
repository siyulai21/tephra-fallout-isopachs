"""Shared directional-continuation experiments and fixed known-volume comparisons."""
import argparse
from pathlib import Path

from benchmarks.mass_mixture import SCENARIOS, case
from src.empirical_isopach.core.catalog import datasets
from src.empirical_isopach.models.directional.study import run_fits
from src.empirical_isopach.models.mass_mixture.study import audited_data


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", required=True, type=Path)
    p.add_argument("--case", choices=[r["slug"] for r in datasets()])
    p.add_argument("--synthetic", choices=SCENARIOS)
    args = p.parse_args(argv)
    if args.synthetic:
        for seed in (10, 11):
            data, _ = case(args.synthetic, seed)
            run_fits(data, 0, args.output/"synthetic"/f"{args.synthetic}-{seed}",
                     all_policies=False, validation=False)
    else:
        for record in datasets():
            if args.case is None or args.case == record["slug"]:
                data, meta = audited_data(record["path"])
                run_fits(data, meta["vent_lonlat"][1], args.output/record["slug"])


if __name__ == "__main__":
    main()

